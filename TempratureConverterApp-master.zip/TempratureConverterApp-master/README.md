# TempratureConverterApp

This is a Simple Basic Android Temprature Converter App, Which Calculate the temprature in .C and .F 
Just Extract The File and Open With Android Studio.

To use this App you have to download the clone
And open with android studion V.2.0 and Above .
And run with inbuilt avd or by using usb cable and enable the debugging mode in Your Phone .
Clcik on Install button and install it in your device 
boom Your App Will Start in Your Device 
...????>>>>>  CONGRATULATION  <<<<<<<<<???????...... 
            You Developed the Android App.
